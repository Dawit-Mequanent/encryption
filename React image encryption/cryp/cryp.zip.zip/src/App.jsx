import React from 'react'
import './App.css'

import File from './assets/components/File/File';

import Muk from './assets/components/Muk/Muk';



function App() {
  return (
    <body>
     
     <Muk/>
     
     <File/>
     
    
      

      
    </body>
    
     
  );
};

export default App
